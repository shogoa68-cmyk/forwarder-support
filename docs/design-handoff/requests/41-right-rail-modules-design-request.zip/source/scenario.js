// ========== 単位で数量を一括変更（旧「シナリオ比較」を作り替え） ==========
// 明細行から単位を抽出し、同じ「単位×現在数量」の行をまとめて表示。
// パネルで数値を変更し「一括反映」すると、その単位・数量の行の数量(pq)を
// まとめて書き換える（請求数量 bq へは既存の連動ロジックで自動反映）。
// 数量がバラつく単位は、現在数量ごとに個別の行として表示する。

  let _udCollapsed = false;
  // グループキーの区切り文字。以前は '\x00'（NUL）を使っていたが、_udRenderPanel() が
  // innerHTML でHTMLを流し込む際、HTMLパーサがNUL文字を U+FFFD に置き換えてしまうため、
  // data-key 属性から読み戻した値と _udCollect() が毎回計算する値が一致せず、
  // パネル再描画（パターン切替・行追加削除等）のたびに除外指定が無効になる不具合があった。
  // 私用領域の文字（実データに出現しない）に変更して回避する。
  const _UD_KEY_SEP = '';
  // 「一括反映」の対象から外したグループ（キー：単位+区切り文字+数量）は、物量パターンごとに
  // conditions.js 側（_packingPatterns[i].excludedUnits）へ記憶・復元する
  // （window._udIsUnitExcluded / window._udSetUnitExcluded 経由）。パターンが無い
  // （conditions.js 未読込等の）環境向けに、フォールバック用のローカル Set も残す。
  const _udExcludedFallback = new Set();
  function _udIsExcluded(key) {
    if (typeof window._udIsUnitExcluded === 'function') return window._udIsUnitExcluded(key);
    return _udExcludedFallback.has(key);
  }
  function _udSetExcluded(key, excluded) {
    if (typeof window._udSetUnitExcluded === 'function') { window._udSetUnitExcluded(key, excluded); return; }
    if (excluded) _udExcludedFallback.add(key); else _udExcludedFallback.delete(key);
  }

  // ---------- 明細から（単位×数量）グループを収集 ----------
  function _udCollect() {
    const map = new Map();   // key: 単位 + 区切り文字 + 数量 → { unit, qty, ids:[] }
    document.querySelectorAll('#tableBody tr[id^="row-"]').forEach(tr => {
      if (tr.dataset.type || tr.dataset.virtual) return;   // リマーク・社内メモ・小計・仮想行は対象外
      const id = tr.id.replace('row-', '');
      const un = (document.getElementById(`un-${id}`)?.value || '').trim();
      if (!un) return;                                     // 単位なしの行は対象外
      const pqEl = document.getElementById(`pq-${id}`);
      if (!pqEl) return;
      const qty = (pqEl.value || '').trim();
      const key = un + _UD_KEY_SEP + qty;
      if (!map.has(key)) map.set(key, { unit: un, qty, ids: [] });
      map.get(key).ids.push(id);
    });
    return Array.from(map.values()).sort((a, b) =>
      a.unit.localeCompare(b.unit, 'ja') || ((parseFloat(a.qty) || 0) - (parseFloat(b.qty) || 0)));
  }

  // ---------- パネル描画 ----------
  function _udRenderPanel() {
    const panel = document.getElementById('scPanel');
    if (!panel) return;
    const groups = _udCollect();

    const listHtml = groups.length
      ? groups.map(g => {
          const key = g.unit + _UD_KEY_SEP + g.qty;
          const included = !_udIsExcluded(key);
          return `<div class="ud-row${included ? '' : ' ud-row--excluded'}" data-ids='${JSON.stringify(g.ids)}' data-key="${escHtml(key)}">
             <input type="checkbox" class="ud-chk" ${included ? 'checked' : ''}
                    onchange="udToggleGroup(this)" title="チェックを外すと「一括反映」の対象から除外します" />
             <span class="ud-unit" title="${escHtml(g.unit)}">${escHtml(g.unit)}</span>
             <span class="ud-times">×</span>
             <input type="number" class="ud-qty-in" value="${escHtml(g.qty)}" min="0" step="1" ${included ? '' : 'disabled'}
                    title="新しい数量を入力して「一括反映」を押すと、この単位・数量の行をまとめて変更します" />
             <span class="ud-count" title="この単位・数量の行数">${g.ids.length}行</span>
           </div>`;
        }).join('')
      : '<p class="ud-empty">単位が設定された明細行がありません。<br>明細行の「単位」欄を入力すると、ここに一覧表示されます。</p>';

    panel.classList.toggle('sc-panel--collapsed', _udCollapsed);
    panel.innerHTML =
      `<div class="sc-head" onclick="scToggleCollapse()" style="cursor:pointer;">
         <span class="sc-head-title">📦 単位で数量を一括変更</span>
         <span class="sc-collapse-arrow">${_udCollapsed ? '▶' : '▼'}</span>
       </div>
       <div class="sc-body">
         ${_udPatternSelectHtml()}
         <div class="qsp-cargo-info ud-cargo-info" id="qspCargoInfo" style="display:none;"></div>
         <p class="sc-hint">明細行の単位ごとに現在の数量を表示します。数値を変えて<b>「一括反映」</b>すると、その単位・数量の行をまとめて更新します。<br>数量がバラつく単位は、現在の数量ごとに分けて表示されます。チェックを外すとその単位を対象から除外できます。</p>
         ${groups.length ? `<div class="ud-select-toggle">
           <span class="ud-select-all" onclick="udSelectAll(true)">すべて選択</span>
           <span class="ud-select-sep">/</span>
           <span class="ud-select-all" onclick="udSelectAll(false)">すべて解除</span>
         </div>` : ''}
         <div class="ud-list">${listHtml}</div>
         <button class="ud-refresh" type="button" onclick="udRefresh()" title="明細から単位を再取得">🔄 再読み込み</button>
         <button class="sc-open-btn" type="button" onclick="udApplyAll()" ${groups.length ? '' : 'disabled'}>✅ 一括反映</button>
       </div>`;

    // 物量情報（旧「輸送」メニューから統合）を数量パネル内に描画
    if (typeof window.renderQuoteCargoInfo === 'function') window.renderQuoteCargoInfo();
  }

  // 貨物情報（荷姿・貨物明細）に複数の想定パターンが登録されている場合、
  // ここから直接切り替えて物量情報（CBM/重量/R-T/CW）を確認できるようにする。
  // 1パターンのみ（未命名）の案件では選択の意味が無いため表示しない
  // （貨物情報側の cdPatternTabs と同じ判定基準）。
  function _udPatternSelectHtml() {
    if (typeof _packingPatterns === 'undefined' || !Array.isArray(_packingPatterns)) return '';
    const onlyOneUnnamed = _packingPatterns.length === 1 && !_packingPatterns[0].name;
    if (onlyOneUnnamed) return '';
    const opts = _packingPatterns.map((pt, i) => {
      const label = pt.name || `パターン${i + 1}`;
      const selected = i === _packingActiveIdx ? ' selected' : '';
      return `<option value="${i}"${selected}>${escHtml(label)}</option>`;
    }).join('');
    return `<div class="ud-pattern-select-row">
      <span class="ud-pattern-select-label">📦 物量パターン</span>
      <select class="ud-pattern-select" onchange="udSwitchPattern(this.value)" title="貨物情報に登録した想定パターンを切り替えて物量情報を確認します">${opts}</select>
    </div>
    <p class="ud-pattern-qty-hint">💡 見積もりテーブルの数量欄（緑枠<span class="pq-pattern-linked-sample"></span>）は、パターンを切り替えて編集すると、その数量がパターンごとに記憶されます（例：「1本の場合」「2本の場合」で行の数量を変えて保存）。橙色の点線枠<span class="pq-pattern-needs-check-sample"></span>は、他のパターンでは数量が個別設定されているのに、今表示中のパターンではまだ設定されていない行です。値は自動では変わらないので、必要なら数量を入力し直してください。</p>`;
  }

  // パターン切替：貨物情報側の状態を更新してからこのパネルを再描画する
  function udSwitchPattern(i) {
    i = parseInt(i, 10);
    if (Number.isNaN(i)) return;
    if (typeof window.switchPackingPattern === 'function') window.switchPackingPattern(i);
    _udRenderPanel();
  }
  window.udSwitchPattern = udSwitchPattern;

  // ---------- 操作 ----------
  function scToggleCollapse() { _udCollapsed = !_udCollapsed; _udRenderPanel(); }
  function udRefresh() { _udRenderPanel(); }

  // グループごとのチェック切り替え（一括反映の対象／対象外）
  function udToggleGroup(chk) {
    const rowEl = chk.closest('.ud-row');
    if (!rowEl) return;
    const key = rowEl.dataset.key || '';
    _udSetExcluded(key, !chk.checked);
    rowEl.classList.toggle('ud-row--excluded', !chk.checked);
    const inp = rowEl.querySelector('.ud-qty-in');
    if (inp) inp.disabled = !chk.checked;
  }

  // すべて選択／すべて解除
  function udSelectAll(on) {
    const panel = document.getElementById('scPanel');
    if (!panel) return;
    panel.querySelectorAll('.ud-row').forEach(rowEl => {
      const chk = rowEl.querySelector('.ud-chk');
      if (chk) { chk.checked = on; udToggleGroup(chk); }
    });
  }

  function udApplyAll() {
    const panel = document.getElementById('scPanel');
    if (!panel) return;
    let unitsChanged = 0, rowsChanged = 0;

    panel.querySelectorAll('.ud-row').forEach(rowEl => {
      if (rowEl.querySelector('.ud-chk')?.checked === false) return;   // チェックを外したグループは対象外
      let ids;
      try { ids = JSON.parse(rowEl.dataset.ids || '[]'); } catch (e) { ids = []; }
      const inp = rowEl.querySelector('.ud-qty-in');
      if (!inp) return;
      const newVal = (inp.value || '').trim();
      if (newVal === '') return;                 // 空欄はスキップ
      let touched = false;
      ids.forEach(id => {
        const pqEl = document.getElementById(`pq-${id}`);
        if (!pqEl) return;
        if ((pqEl.value || '').trim() !== newVal) {
          pqEl.value = newVal;
          // input イベントで既存の oninput（onPay → 請求数量連動・再計算・合計更新・自動保存）を発火
          pqEl.dispatchEvent(new Event('input', { bubbles: true }));
          rowsChanged++; touched = true;
        }
      });
      if (touched) unitsChanged++;
    });

    if (typeof updateTotals === 'function') updateTotals();
    _udRenderPanel();

    if (rowsChanged === 0) {
      if (typeof quoteShowToast === 'function') quoteShowToast('変更はありませんでした', 'info', 2500);
      return;
    }

    // 一括変更後：ユーザーに尋ねて印刷（プレビュー）モーダルを開く
    if (window.confirm(`${unitsChanged}単位・計${rowsChanged}行の数量を一括変更しました。\n印刷プレビューを開きますか？`)) {
      if (typeof openPreview === 'function') openPreview();
      else if (typeof window.openPreview === 'function') window.openPreview();
      else window.print();
    } else if (typeof quoteShowToast === 'function') {
      quoteShowToast(`数量を一括変更しました（${rowsChanged}行）`, 'success', 2500);
    }
  }

  // ---------- 初期化 ----------
  function initScenarios() {
    _udRenderPanel();
    // 明細の追加・削除に追従してパネルを再描画
    const tbody = document.getElementById('tableBody');
    if (tbody && typeof MutationObserver !== 'undefined') {
      let _t = null;
      new MutationObserver(() => {
        clearTimeout(_t);
        _t = setTimeout(() => { if (!_udCollapsed) _udRenderPanel(); }, 300);
      }).observe(tbody, { childList: true });
    }
  }

  // ---------- window 公開 ----------
  window.initScenarios    = initScenarios;
  window.scToggleCollapse = scToggleCollapse;
  window.udRefresh        = udRefresh;
  window.udApplyAll       = udApplyAll;
  window.udToggleGroup    = udToggleGroup;
  window.udSelectAll      = udSelectAll;
