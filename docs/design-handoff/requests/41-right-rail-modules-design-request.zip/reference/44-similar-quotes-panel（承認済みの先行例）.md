# 類似見積パネル（#sqPanel）の改修：決定（Design → Code）

「右レール『🔍 類似見積』パネルのデザイン見直し」への回答です。
- 画面の画像：images/sq-1〜7（Industry・幅340px／スマホ390px・2倍）
- 動く画面案：reference/Similar Quotes Panel.dc.html（状態と迷う点を切り替え）
- 画像と同じ見た目の素の HTML：reference/similar-quotes-mock.html（CSS をそのまま見られます）

## 0. 迷う点の決定
| 点 | 決定 |
|---|---|
| 近道ボタン | **S2：あり**。入口カードの下に、いまの条件の札（🏢お客様・📦POL・🏁POD・モード）と［⚡ この見積の条件で探す］。押すと検索画面に切り替え、すぐに結果まで出す（新しい関数1つで sqStartSearch()→sqDoSearch() を続けて呼ぶ。既存の関数名は変えない）。条件が1つも無い見積では、札とボタンを出さず「この見積にはまだ条件（お客様・港・モード）がありません。上のカードから、条件を入れて探せます。」の1行。 |
| 条件欄の初期表示 | **C1：よく使う4つ＋［さらに条件（状態・見積もり番号） ▾］**。お客様・見積名／POL／POD／輸送モードを先に。状態と見積もり番号は ▾ の奥（表示の出し分けだけ）。▾ の中に値が入っているときは、最初から開いておく。 |
| 類似度の見せ方 | **M1：一致の札＋「N/5 一致」**。●○○ の代わりに、名前の右に「3/5 一致」（12px 太字・緑）。下に5条件の札：一致＝緑の面「✓ お客様」、不一致＝灰の面・灰の字・取り消し線。並びは一致→不一致。条件の比べ方は今の _sqScore と同じ（探す側の条件が空の条件は札を出さず、分母も減らす。例「2/3 一致」）。 |

## 1. 2つの箱の区切り（3-4）
- 上「🔗 関連付けた案件」：背景 #f8f9fb（薄い灰）。見出し 14px 太字＋12px 灰の説明「手で結んだ案件」、右に［＋ 関連付け］（30px・白・枠）。空のとき：点線の枠の中に「まだありません。多レグの相方や代替案を［＋ 関連付け］で結べます。」
- あいだ：高さ 8px の灰の帯（#eef0f3・上下に 1px の線）。
- 下「🔍 似ている案件を探す」：白い面。見出し 14px 太字＋12px 灰「過去の案件から」。
- 関連付けた案件の箱は、保存前の新規見積では出ない（今どおり）。

## 2. 入口の状態（3-1）images/sq-1・sq-2
- カードは新規見積の .nq-card と同じ作り・同じ言葉。**横並び**：左にアイコン 26〜28px、題「似ている案件を探す」16px 太字、説明 12px（行間1.7）、右に「›」（主色）。
- 背景は主色の薄い面（Industry #eef3fb）・枠 #bcd0ee・角丸8px・余白14px。ホバー・フォーカスで枠を主色に。
- その下に近道（0.参照）。［⚡ この見積の条件で探す］は主色の塗り・横幅いっぱい・36px。

## 3. 検索画面（3-2）images/sq-3・sq-4・sq-6
- 見出し行：左に［‹ 戻る］（30px・枠・入口へ＝sqBackToIntro）、右に題。いまの ✕ は「閉じる」と紛らわしいので、見た目を［‹ 戻る］にする（同じ onclick）。
- 欄：**上にラベル**（12px 太字・灰）、欄は高さ36px・角丸6px・14px。POL と POD は2列（引き出しが 300px 未満のときは1列）。
- チップ：高さ32px・13px 太字・丸い形（999px）。選択中＝**主色の薄い面＋主色の枠（内側にもう1px）＋主色の文字**。黒の塗りはやめる。
- ボタン：［🔍 探す］＝主色の塗り・**横幅いっぱい**・36px・14px 太字。［条件をクリア］＝枠なし・灰の文字・下線（副）。ボタン行の上に1px の線。
- 結果エリアの状態：
  - 探す前：中央に 🗂（30px）＋「条件を確かめて［探す］を押してください」（14px 太字）＋「条件が空でも探せます（新しい順）。Enter キーでも探せます。」（12px）
  - 検索中：「探しています…」＋灰の仮カード3枚（高さ78px）。［探す］は押せない状態に。
  - 結果：「**N 件**が見つかりました」（件数14px太字）＋右に「似ている順」（12px灰）。
  - 該当なし：中央に 🔎＋「該当する案件はありません」＋「条件を減らすと見つかることがあります。例：お客様名を消す・モードを『すべて』に。」＋［条件をクリアしてもう一度］（sqClearSearch のあと sqDoSearch）。

## 4. 結果カード（3-3）images/sq-5
- 1枚ずつ箱にする：左右14pxの余白・角丸8px・枠1px・カードの間8px。左の色の線（sq-card--hi／--mid）はやめる。
- 中の順番：
  1. 案件名 14px 太字・1行で「…」省略。右に「N/5 一致」と「›」。
  2. お客様 13px。
  3. ルート「POL → POD」・モード・貿易条件 12px（灰の濃いほう）。
  4. 一致の札（0.参照）。
  5. ステータスの札・見積もり番号・日付（右寄せ）12px 灰。
- カード全体が押せる：ホバー・フォーカスで枠を主色＋外側に 3px の薄い主色の光。tabindex="0" を付け、Enter・Space でもプレビュー（sqOpenPreview）。
- ［もっと見る（あと N 件） ▾］：幅いっぱい（左右14px）・36px・枠・主色の文字。

## 5. スマホ（〜600px・下から出るシート）images/sq-7
- チップ・欄・ボタンは 44px。文字はトークンが一段上がる（今どおり）。
- ［🔍 探す］［クリア］を**シートの下に固定**（キーボードが出ても押せる）。
- 結果カードの作りは PC と同じ。

## 6. CSS の方針
- すべてのセレクタの頭に **#sqPanel** を付ける（例 `#sqPanel .sq-mode-chip.is-on`）。#tab-quote-make 配下の input・button の共通ルールに勝てる。!important は使わない。
- 色は #sqPanel に変数を置き、テーマごとに上書き：
  - `--sq-pri`（主色）・`--sq-pri-50`（薄い面）・`--sq-pri-200`（入口カードの枠）・`--sq-ok`／`--sq-ok-50`（一致の緑）。
  - Industry：#2f5fb3／#eef3fb／#bcd0ee／#067647／#ecfdf3。現行：--accent 系（--accent／--accent-lt）・緑は --green-ok。Quiet：--q-accent 系。
- 文字は --text-xs／sm／base／lg だけ。
- HTML の追加（_sqSearchHtml の中だけ・id／onclick は不変）：各欄を `<div class="sq-f"><label class="sq-f-lbl" for="sqSearchPol">積み港 POL</label>…</div>` で包む。「さらに条件」用に `<div class="sq-more-cond" hidden>` で状態と見積もり番号を包む。_sqCardHtml に一致の札 `<div class="sq-match"><span class="sq-m is-hit">✓ お客様</span>…</div>` と「›」を足す。
- 例（Industry）：
```
#sqPanel{--sq-pri:#2f5fb3;--sq-pri-50:#eef3fb;--sq-pri-200:#bcd0ee;--sq-ok:#067647;--sq-ok-50:#ecfdf3}
#sqPanel .sq-mode-chip,#sqPanel .sq-status-chip{min-height:32px;padding:0 12px;border-radius:999px;font-size:var(--text-sm);font-weight:600;border:1px solid var(--border);background:var(--surface)}
#sqPanel .sq-mode-chip.is-on,#sqPanel .sq-status-chip.is-on{background:var(--sq-pri-50);border-color:var(--sq-pri);color:var(--sq-pri);box-shadow:inset 0 0 0 1px var(--sq-pri)}
#sqPanel .sq-go-btn{flex:1;min-height:36px}
#sqPanel .sq-clear-btn{border:0;background:none;text-decoration:underline;text-underline-offset:3px}
#sqPanel .sq-card{margin:0 14px 8px;border:1px solid var(--border);border-radius:8px}
#sqPanel .sq-card:hover,#sqPanel .sq-card:focus-visible{border-color:var(--sq-pri);box-shadow:0 0 0 3px var(--sq-pri-50);outline:none}
#sqPanel .sq-m{font-size:var(--text-xs);font-weight:600;border-radius:4px;padding:0 6px;line-height:20px;background:#f2f4f7;color:#98a2b3;text-decoration:line-through}
#sqPanel .sq-m.is-hit{background:var(--sq-ok-50);color:var(--sq-ok);text-decoration:none}
@media (max-width:600px){#sqPanel .sq-mode-chip,#sqPanel .sq-status-chip,#sqPanel .sq-search-input,#sqPanel .sq-go-btn{min-height:44px}}
```
- 300px（いちばん狭い）でも1列で読めること：POL／POD は `@container` か幅判定で1列に。チップは折り返してよい。

## 7. 制約の確認
機能は消さない。DOM・id・onclick・関数名は変えない（クラス・包みの div／label・CSS・表示の出し分けと、近道の新しい関数1つを足すだけ）。3テーマ・旧画面でも崩れない。保存データと検索の問い合わせは変えない。

## 8. Code への確認
1. 近道の新しい関数名（例 `sqQuickSearch`）でよいか。
2. 一致の札で「探す側の条件が空の条件は出さない（分母を減らす）」でよいか。
3. ［‹ 戻る］の見た目に変えても、右上の引き出しの✕（閉じる）と取り違えないか、旧画面でも確かめてほしい。
